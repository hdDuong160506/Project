Cần làm để build và chạy server

1. Tạo file .env trong folder template này và copy phần này vào

SUPABASE_URL=https://cbrjblrrnyejkeazgymq.supabase.co
SUPABASE_SERVICE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNicmpibHJybnllamtlYXpneW1xIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2NDEyNjgzNSwiZXhwIjoyMDc5NzAyODM1fQ.KPU91etXLSNVv5crdBYKuEJXppEg-3BNA0wCWafEw3U
SECRET_KEY=bi-mat-cua-ban


2. Tạo một file .env bên trong DangKy/API
Nội dung .env:
GEMINI_API_KEY=AIzaSyA-TF_uFo-ToX2pC5kWA1iRmAhUpg99jg0
DATA_BASE_URL_SUPABASE=https://cbrjblrrnyejkeazgymq.supabase.co
DATA_BASE_SECRET_KEY_SUPABASE=sb_secret_ebUeQEhMmX9fg0FZI1Oz2Q_EMiK3JTG

3. Tạo một file .env bên trong DangKy/database
Nội dung .env:
DATA_BASE_URL_SUPABASE=https://cbrjblrrnyejkeazgymq.supabase.co
DATA_BASE_SECRET_KEY_SUPABASE=sb_secret_ebUeQEhMmX9fg0FZI1Oz2Q_EMiK3JTG

Chạy run.py
chạy đường link terminal.