Cần làm để build và chạy server

1. Tạo file .env trong folder backend và copy phần này vào

SUPABASE_URL=https://cbrjblrrnyejkeazgymq.supabase.co
SUPABASE_SERVICE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNicmpibHJybnllamtlYXpneW1xIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2NDEyNjgzNSwiZXhwIjoyMDc5NzAyODM1fQ.KPU91etXLSNVv5crdBYKuEJXppEg-3BNA0wCWafEw3U
SECRET_KEY=bi-mat-cua-ban


2. Tạo một file .env bên trong backend cùng cấp với run.py và copy phần này vào

GROQ_FIX_TEXT_API_KEY=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
GROQ_SEARCH_IMAGE_API_KEY=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
DATA_BASE_URL_SUPABASE=https://cbrjblrrnyejkeazgymq.supabase.co
DATA_BASE_SECRET_KEY_SUPABASE=sb_secret_ebUeQEhMmX9fg0FZI1Oz2Q_EMiK3JTG