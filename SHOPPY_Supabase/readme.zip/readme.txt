tạo file .env trong folder DangKy và copy phần này vào

SUPABASE_URL=https://cbrjblrrnyejkeazgymq.supabase.co
SUPABASE_SERVICE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNicmpibHJybnllamtlYXpneW1xIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2NDEyNjgzNSwiZXhwIjoyMDc5NzAyODM1fQ.KPU91etXLSNVv5crdBYKuEJXppEg-3BNA0wCWafEw3U
SECRET_KEY=bi-mat-cua-ban


chạy lệnh run.py
sau đó đăng nhập bằng link trên terminal