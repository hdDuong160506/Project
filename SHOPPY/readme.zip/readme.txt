tạo 1 file .env ghi tất cả này vào và để trong file DangKy

# --- Key bí mật cho JWT và Token (Tạo một chuỗi ngẫu nhiên, dài) ---
JWT_SECRET_KEY=day_la_key_bi_mat_cua_toi_ban_hay_thay_doi_no_12345

# --- Cấu hình Gmail để gửi mail ---
# (Dùng tài khoản Gmail và Mật khẩu Ứng dụng 16 chữ số)
MAIL_USERNAME=huynhducduongcute@gmail.com
MAIL_PASSWORD=bflo kjcy pxmj chbd

GOOGLE_CLIENT_ID=966935095549-b8f7a74pmsm4blol68jstqbnh0ai662a.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=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